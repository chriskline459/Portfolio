Hi! Welcome to the SchoolQuest Demo installation guide!
Below are simple steps to follow to get our application up and runnning on your device.
=======================================================================================
1. Download Visual Studio Code. (Or any IDE that supports Python, HTML, and Javascript. 
Here's a link to VS Code: https://code.visualstudio.com/download)

2. Install Python on whatever machine you are using via https://www.python.org/downloads/. Make
sure that you have Python added to your PATH environmental variable. Instructions on how to do this
can be found at https://www.educative.io/edpresso/how-to-add-python-to-path-variable-in-windows.

3. Open Visual Studio Code, and install the following extensions:
	a. Pylance
	b. Python
	c. npm
	d. Language support for Java
	e. C/C++

4. Open the terminal using the "Terminal" -> "New Terminal", and enter the following commands:
	a. pip install flask
	b. pip install flask-login
	c. pip install flask-sqlalchemy
	d. pip install psutil
	e. pip install bs4

5. Open the folder in Visual Studio Code. (In the top left, "File" -> "Open Folder" -> Folder Destination)

6. Run the main.py file in Visual Studio code. 

7. Click on the link presented in the terminal to navigate to the running application.
(It should be a short IP, and look something like http://127.0.0.1:5000).

8. You are now on the SchoolQuest sign-up page. In order to navigate to the rest of the website, 
simply create an account and login.

Thank you for taking the time to review our application, it means a great deal to our team!

Application Credits:
Gian-Soren Morici, John Paul Dangler, Christian Kline, Hunter Sheng, Ivan Huang
Rutgers Computer Engineering Program Class of 2022 Capstone Project