"""Unit test package for {{ cookiecutter.project_slug }}."""
