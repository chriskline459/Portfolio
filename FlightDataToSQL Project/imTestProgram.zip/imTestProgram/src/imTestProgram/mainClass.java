package imTestProgram;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class mainClass {

	public static void main(String[] args) {
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		SQLiteFrameWork test = new SQLiteFrameWork();
		ResultSet rs;
		
		try {
			rs = test.displayUsers();
			int rowcount = 0; // used for determining if an aid already exists in database
			String msgType = null;
			
			// -------- Start of Parser --------
			
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse("NewAirType2.xml");   // EXPERIMENT
			
			//-------- Code for determining if message is flt, mrp, eta, sta --------
			
			NodeList nodeList=doc.getElementsByTagName("*");
			
		    Element element = (Element)nodeList.item(3);
		    msgType = element.getNodeName();
		    System.out.println("Type of inputted message: " + msgType);
		    
		    if (msgType.compareTo("flt") == 0)
		    {
		    	System.out.println("Message type is flt");
		    }
		    else
		    {
		    	System.out.println("Message type is NOT flt");
		    }
		    
		    //-------- Code for pulling flight info based on message type --------
			
			NodeList fltList = doc.getElementsByTagName("flt");    // Pulls out all elements if tag 'flt' exists in xml doc
			
			for(int i=0;i<fltList.getLength();i++) // flt list is only 1 column (loop might not be necessary)
			{
				Node f = fltList.item(i);
				if(f.getNodeType()==Node.ELEMENT_NODE)
				{
					Element flight = (Element) f;
					NodeList atList = flight.getChildNodes(); 
						
					String aid = atList.item(1).getTextContent();
					String dap = atList.item(3).getTextContent();
					String apt = atList.item(5).getTextContent();
					String fps = atList.item(7).getTextContent();
					String acs = atList.item(9).getTextContent();
					String typ = atList.item(11).getTextContent();
					String eng = atList.item(13).getTextContent();
					String bcn = atList.item(15).getTextContent();
					String spd = atList.item(17).getTextContent();
					String ara = atList.item(19).getTextContent();
					String ina = atList.item(21).getTextContent();
					String trw = atList.item(23).getTextContent();
					String drw = atList.item(25).getTextContent();
					String tds = atList.item(27).getTextContent();
					String cfx = atList.item(29).getTextContent();
					String ctm = atList.item(31).getTextContent();
					String etd = atList.item(33).getTextContent();
					String std = atList.item(35).getTextContent();
					String etm = atList.item(37).getTextContent();
					String est = atList.item(39).getTextContent();
					String a10 = atList.item(41).getTextContent();
					String tcr = atList.item(43).getTextContent();	
					
					// -------- Below code goes displays flights in table --------
					// Code also does logic to determine if a flight exists already by going through and comparing aid for each flight
					
					System.out.println("--Current Flights in Table--");
					String temp = null;
					
					while(rs.next()) {
						temp = rs.getString("aid");
						
						System.out.println(rs.getString("aid") + " " + rs.getString("dap") + " " + rs.getString("apt"));
						if (temp.compareTo(aid) == 0) // Nice hack to compare string tags
						{
							rowcount++; // Increments rowcount if there is a hit
							System.out.println("True(Strings are equal)");
						}
						else
						{
							System.out.println("False");
						}
					}
					System.out.println("--End of Flights in Table--");
					System.out.println(" ");
				
					if (rowcount == 0) // rowcount will equal 0 if there is no other hits on the given aid
					{
						test.addFltData(aid, dap, apt, fps, acs, typ, eng, bcn, spd, ara, ina, trw,  drw, tds, cfx, ctm, etd, std, etm, est, a10, tcr);
						System.out.println("Flight confirmed.");
					}
					else
					{
						System.out.println("Flight already exists within table.");
					}
					//aid = "AAL2101";
					//test.updateFltData(aid, dap, apt, fps, acs, typ, eng, bcn, spd, ara, ina, trw,  drw, tds, cfx, ctm, etd, std, etm, est, a10, tcr);
				}
			}
			
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}