package imTestProgram;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SQLiteFrameWork {
	
	private static Connection con;
	private static boolean hasData = false;
	
	public ResultSet displayUsers() throws ClassNotFoundException, SQLException {
		if (con == null) {
			getConnection(); // This method is used for displaying pre-existing flights
		}                    // NOTE: the result set can only be traversed through ONCE (limitations of sqlite)
		
		Statement state = con.createStatement();
		ResultSet res = state.executeQuery("SELECT aid, dap, apt, fps, acs, typ, eng, bcn, spd, ara, ina, trw,  drw, tds, cfx, ctm, etd, std, etm, est, a10, tcr FROM user");
		return res;
	}

	private void getConnection() throws ClassNotFoundException, SQLException {
		Class.forName("org.sqlite.JDBC");
		con = DriverManager.getConnection("jdbc:sqlite:swimDataFeed10.db");   // NAME OF DB FILE THAT IS STORED IN C: DRIVE
		initialise();
	}

	private void initialise() throws SQLException { // Method that actually creates the database
		if ( !hasData ) {
			hasData = true;
			
			Statement state = con.createStatement();
			ResultSet res = state.executeQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='user'");
			if ( !res.next() ) {
				System.out.println("Building the User table with prepopulated values."); // only prints when initially run
				// building the table
				Statement state2 = con.createStatement();
				
				state2.execute("CREATE TABLE user(id integer,"  // Statement that creates the db itself
						+ "aid varchar(60)," + "dap varchar(60)," + "apt varchar(60)," + "fps varchar(60)," + "acs varchar(60)," + "typ varchar(60),"
						+ "eng varchar(60)," + "bcn varchar(60)," + "spd varchar(60)," + "ara varchar(60)," + "ina varchar(60)," + "trw varchar(60),"
						+ "drw varchar(60)," + "tds varchar(60)," + "cfx varchar(60)," + "ctm varchar(60)," + "etd varchar(60)," + "std varchar(60),"
						+ "etm varchar(60)," + "est varchar(60)," + "a10 varchar(500)," + "tcr varchar(500),"
						+ "primary key(id));"); // a10 and tcr are given 500 chars as they are usually bigger
			}
		}	
	}


	public void addFltData (String aid, String dap, String apt, String fps, String acs, String typ, String eng, String bcn, String spd, String ara, String ina, String trw, String drw, String tds, String cfx, String ctm, String etd, String std, String etm, String est, String a10, String tcr) throws ClassNotFoundException, SQLException {
	
		if (con == null) { // Creates database if not created already
			getConnection();
		}
		
		PreparedStatement prep = con.prepareStatement("INSERT INTO user(aid, dap, apt, fps, acs, typ, eng, bcn, spd, ara, ina, trw,  drw, tds, cfx, ctm, etd, std, etm, est, a10, tcr) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);");
		prep.setString(1, aid);
		prep.setString(2, dap);
		prep.setString(3, apt); // This method adds arguments to database (already created at this point)
		prep.setString(4, fps); // Each tag is assigned to its own number (i.e. fps = 4, aid = 1, ara = 10, etc.)
		prep.setString(5, acs);
		prep.setString(6, typ);
		prep.setString(7, eng);
		prep.setString(8, bcn);
		prep.setString(9, spd);
		prep.setString(10, ara);
		prep.setString(11, ina);
		prep.setString(12, trw);
		prep.setString(13, drw);
		prep.setString(14, tds);
		prep.setString(15, cfx);
		prep.setString(16, ctm);
		prep.setString(17, etd);
		prep.setString(18, std);
		prep.setString(19, etm);
		prep.setString(20, est);
		prep.setString(21, a10);
		prep.setString(22, tcr);
		prep.execute();
			
		System.out.println("Flight Added (flt): " + aid + ", from " + dap + " to " + apt);
		System.out.println(" ");
	}
	
	public void updateFltData (String aid, String dap, String apt, String fps, String acs, String typ, String eng, String bcn, String spd, String ara, String ina, String trw, String drw, String tds, String cfx, String ctm, String etd, String std, String etm, String est, String a10, String tcr) throws ClassNotFoundException, SQLException {
		
		if (con == null) { // Creates database if not created already
			getConnection();
		}
		
		String sql = "UPDATE user SET dap = ?,"  // Here, aid is taken at the end with WHERE
				+ "apt = ?," + "fps = ?," + "acs = ?," // This method will only update message that have a matching aid
				+ "typ = ?," + "eng = ?," + "bcn = ?,"
				+ "spd = ?," + "ara = ?," + "ina = ?,"
				+ "trw = ?," + "drw = ?," + "tds = ?,"
				+ "cfx = ?," + "ctm = ?," + "etd = ?,"
				+ "std = ?," + "etm = ?," + "est = ?,"
				+ "a10 = ?," + "tcr = ?"  + "WHERE aid = ?";
		
		PreparedStatement pstmt = con.prepareStatement(sql);
		
		pstmt.setString(1, dap); // Similar to the addFltData method, each tag has it's own corresponding number
		pstmt.setString(2, apt);
		pstmt.setString(3, fps);
		pstmt.setString(4, acs);
		pstmt.setString(5, typ);
		pstmt.setString(6, eng);
		pstmt.setString(7, bcn);
		pstmt.setString(8, spd);
		pstmt.setString(9, ara);
		pstmt.setString(10, ina);
		pstmt.setString(11, trw);
		pstmt.setString(12, drw);
		pstmt.setString(13, tds);
		pstmt.setString(14, cfx);
		pstmt.setString(15, ctm);
		pstmt.setString(16, etd);
		pstmt.setString(17, std);
		pstmt.setString(18, etm);
		pstmt.setString(19, est);
		pstmt.setString(20, a10);
		pstmt.setString(21, tcr);
		pstmt.setString(22, aid);
		pstmt.executeUpdate();
		
		System.out.println("Flight Updated.");
	}
}