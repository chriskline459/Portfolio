package {{cookiecutter.package}};

import org.junit.Test;

public class MainTest {
    @Test
    public void canMain() {
        Main.main();
    }
}

