/**
 * Main package for cookiecutter-java.
 */
